package com.example.flutter_task_nada_mohsen_salah

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

import 'package:flutter/cupertino.dart';
import 'package:flutter_task_nada_mohsen_salah/module/Home/home_screen.dart';
import 'package:flutter_task_nada_mohsen_salah/module/Home/mobile_screen.dart';

class AppLayout extends StatefulWidget {
  const AppLayout({super.key});

  @override
  State<AppLayout> createState() => _AppLayoutState();
}

class _AppLayoutState extends State<AppLayout> {
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
        builder: (context, constraints) =>
        constraints.maxWidth < 800 ?  const MobileScreen(): const HomeScreen()  ,);
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:flutter_task_nada_mohsen_salah/core/Style/AppColors.dart';
import 'package:flutter_task_nada_mohsen_salah/module/Home/widget/home_container.dart';

class MobileScreen extends StatefulWidget {
  const MobileScreen({super.key});

  @override
  State<MobileScreen> createState() => _MobileScreenState();
}

class _MobileScreenState extends State<MobileScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar (
        title: Row(
          children: [
            SvgPicture.asset("assets/images/svg/menu.svg",),
            SizedBox(width: 8.w,),
            SvgPicture.asset("assets/images/svg/logo.svg", width: 82.w,height: 40 .h,),
          ],
        ),
        actions: [
          SvgPicture.asset("assets/images/svg/settings.svg",
            width: 24.w,
            height: 24.h,
          ),
          SizedBox(width: 15.w,),
          SvgPicture.asset("assets/images/svg/notification.svg",
            width: 24.w,
            height: 24.h,
          ),
          SizedBox(width: 12.w,),
          RotatedBox(
            quarterTurns: -1,
            child: Container(
              width: 22.w,
              height: 1.h,
              decoration: BoxDecoration(
                color: AppColors.dividerColor,
              ),
            ),
          ),
          SizedBox(width: 12.w,),
          Image.asset("assets/images/svg/profileImg.png",
            width: 32.w,
            height: 32.h,
          ),
        ],
      ),
      body: Column(
        children: [
          Divider(color: AppColors.dividerColor,),
           Padding(
             padding: const EdgeInsets.symmetric(horizontal: 16),
             child: Row(
               mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("Items", style: Theme.of(context).textTheme.displaySmall?.copyWith(
                  fontSize: 32.sp,
                  color: AppColors.whiteColor,
                  fontWeight: FontWeight.w400),
              ),
              SvgPicture.asset("assets/images/svg/filter.svg",width: 40.w,height: 40.h,),
            ],
          ),
          ),
          Expanded(
            child: ListView.separated(
                itemBuilder: (context, index) => const HomeContainer(),
                separatorBuilder: (context, index) =>SizedBox(height: 16.h,) ,
                itemCount: 5),
          )
        ],
      ),
    );
  }
}

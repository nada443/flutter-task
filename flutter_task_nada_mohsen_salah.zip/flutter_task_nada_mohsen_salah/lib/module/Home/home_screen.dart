import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_svg/svg.dart';
import 'package:flutter_task_nada_mohsen_salah/core/Style/AppColors.dart';
import 'package:flutter_task_nada_mohsen_salah/core/components/custom_tabbar.dart';
import 'package:flutter_task_nada_mohsen_salah/module/Home/items_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>  with SingleTickerProviderStateMixin{
  TabController? tabController;


  @override
  void initState() {
    super.initState();
   tabController = TabController(length: 5, vsync: this);
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
       children: [
         Padding(
           padding: const EdgeInsets.symmetric(horizontal: 80),
           child: IntrinsicHeight(
             child: Row(
               mainAxisSize: MainAxisSize.min,
               children: [
                 SvgPicture.asset("assets/images/svg/logo.svg",
                   width: 82.w,
                   height: 40.h,
                 ),
                const Spacer(),
                 Expanded(
                   child: CustomTabBar(
                     isScrollable: false,
                     tabController:tabController,
                     tabs:const [
                       Tab(
                         text: "Items",
                       ),
                       Tab(
                         text: "Pricing",
                       ),
                       Tab(
                         text: "Info",
                       ),
                       Tab(
                         text: "Tasks",
                       ),
                       Tab(
                         text: "Analytics",
                       ),
                     ],
                   ),
                 ),

                 RotatedBox(
                   quarterTurns: -1,
                   child: Container(
                     width: 10.w,
                     height: 1.h,
                     decoration: BoxDecoration(
                       color: AppColors.dividerColor,
                     ),
                   ),
                 ),
                 SizedBox(width: 15.w,),
                 SvgPicture.asset("assets/images/svg/settings.svg",
                   width: 24.w,
                   height: 24.h,
                 ),
                 SizedBox(width: 15.w,),
                 SvgPicture.asset("assets/images/svg/notification.svg",
                   width: 24.w,
                   height: 24.h,
                 ),
                 SizedBox(width: 10.w,),
                 RotatedBox(
                   quarterTurns: -1,
                   child: Container(
                     width: 10.w,
                     height: 1.h,
                     decoration: BoxDecoration(
                       color: AppColors.dividerColor,
                     ),
                   ),
                 ),
                 SizedBox(width: 10.w,),
                 Image.asset("assets/images/svg/profileImg.png",
                   width: 32.w,
                   height: 32.h,
                 ),
                 SizedBox(width: 8.w,),
                 Text("John Doe", style: Theme.of(context).textTheme.displaySmall?.copyWith(
                   fontSize: 14.sp,
                   color: AppColors.whiteColor,
                   fontWeight: FontWeight.w400),
                 ),
                 SizedBox(width: 4.w,),
                 SvgPicture.asset("assets/images/svg/chevron-down.svg",
                   width: 16.w,
                   height: 16.h,
                 ),

               ],
             ),
           ),
         ),
         Divider(color: AppColors.greyColor.withOpacity(0.4),
         height: 1,),
         SizedBox(height: 36.h,),
         Expanded(
           child: TabBarView(
             controller: tabController,
             children: const [
               ItemsScreen(),
               ItemsScreen(),
               ItemsScreen(),
               ItemsScreen(),
               ItemsScreen(),
             ],
           ),
         ),
       ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_task_nada_mohsen_salah/core/Style/AppColors.dart';

class HomeContainer extends StatefulWidget {
  const HomeContainer({super.key});

  @override
  State<HomeContainer> createState() => _HomeContainerState();
}

class _HomeContainerState extends State<HomeContainer> {
  List<String> randomImages = [
    "assets/images/svg/profileImg.png",
    "assets/images/png/three.png",
    "assets/images/png/profileImfTwo.png"];
  @override
  Widget build(BuildContext context) {

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Container(
        decoration: BoxDecoration(
            color: const Color(0xff171717),
            borderRadius: BorderRadius.circular(15)
        ),
        clipBehavior: Clip.antiAlias,
        width: 343.w,
        height: 314.h,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Stack(
                clipBehavior: Clip.antiAlias,
                fit: StackFit.loose,
                children: [
                  Image.asset("assets/images/png/listImg.png",fit: BoxFit.cover,width: 400.w,height: 314.h,),
                  Positioned(
                    right: 8,
                    top: 8,
                    child: SvgPicture.asset("assets/images/svg/editIcon.svg",width: 32.w,height: 32.h,),),
                ],
              ),
            ),
            Container(
              margin: const EdgeInsets.only(left: 16,top: 16),
              width: 156.w,
              height: 32.h,
              //padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 4),
              decoration: BoxDecoration(
                color:AppColors.orangeColor.withOpacity(0.2),
                border: Border.all(
                    color: AppColors.orangeColor
                ),
                borderRadius:BorderRadius.circular(25),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Pending Approval",style: Theme.of(context).textTheme.displayMedium?.copyWith(
                      color: AppColors.whiteColor,
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w400
                  ),),
                  SizedBox(width: 10.w,),
                  SvgPicture.asset("assets/images/svg/chevron-down.svg",
                    width: 20.w,
                    height: 20.h,
                  ),
                ],
              ),
            ),
            SizedBox(height: 10.h,),
            Padding(
              padding:  EdgeInsets.only(left: 15.0.w),
              child: Text("Item title",style: Theme.of(context).textTheme.displayMedium?.copyWith(
                  color: AppColors.whiteColor,
                  fontSize: 18.sp,
                  fontWeight: FontWeight.w400
              ),),
            ),
            SizedBox(height: 6.h,),
            Padding(
              padding: const EdgeInsets.only(left: 15.0),
              child: Wrap(
                alignment: WrapAlignment.start,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  SvgPicture.asset("assets/images/svg/calendar.svg",
                    height: 16.h,
                    width: 16.w,),
                  SizedBox(width: 6.w,),
                  Text("Jan 16 - Jan 20, 2024",style: Theme.of(context).textTheme.displaySmall,)

                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15.0),
              child: Divider(
                thickness: 1.h,
                color: AppColors.dividerColor,
              ),
            ),
            SizedBox(height: 12.h,),
            Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15.0),
                child:  Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    for (int i = 0; i < randomImages.length; i++)
                      Align(
                        widthFactor: 0.5.w,
                        // parent circle avatar.
                        // We defined this for better UI
                        child: CircleAvatar(
                          radius: 15.w,
                          backgroundColor: Colors.white,
                          // Child circle avatar
                          child: CircleAvatar(
                            radius: 15.w,
                            backgroundImage: AssetImage(randomImages[i]),
                          ),
                        ),
                      ),
                    Align(
                      widthFactor: 0.5.w,
                      // parent circle avatar.
                      // We defined this for better UI
                      child: CircleAvatar(
                        radius: 15.w,
                        backgroundColor: AppColors.dividerColor,
                        // Child circle avatar
                        child: CircleAvatar(
                          backgroundColor: AppColors.dividerColor,
                          radius: 15.w,
                          child: Text("+6",style: Theme.of(context).textTheme.displaySmall?.copyWith(
                              color: AppColors.yellowColor,
                              fontWeight: FontWeight.w700,
                              fontSize: 8.5.sp
                          ),),
                        ),
                      ),
                    ),

                    const Spacer(),
                    Text("4 unfinished tasks",style: Theme.of(context).textTheme.displaySmall?.copyWith(
                        fontSize: 12.sp
                    ),),
                  ],
                )
            ),
          ],
        ),
      ),
    );
  }
}

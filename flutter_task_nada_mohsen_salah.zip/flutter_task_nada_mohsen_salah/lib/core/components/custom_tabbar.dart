import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_task_nada_mohsen_salah/core/Style/AppColors.dart';

class CustomTabBar extends StatelessWidget {
  final List<Tab> tabs;
  final TabController? tabController;
  bool isScrollable;

  CustomTabBar(
      {required this.tabs, this.tabController, this.isScrollable = false});

  @override
  Widget build(BuildContext context) {
    return TabBar(
        isScrollable: isScrollable,
        indicatorSize: TabBarIndicatorSize.label,
        dividerColor: Colors.transparent,
        controller: tabController,
        indicatorColor: AppColors.yellowColor,
        labelStyle:Theme.of(context).textTheme.displayMedium,
        unselectedLabelStyle:Theme.of(context).textTheme.displayMedium,
        padding: EdgeInsets.zero,
        tabAlignment: isScrollable ? TabAlignment.start : null,
        labelPadding: const EdgeInsets.symmetric(horizontal: 10.0),
        labelColor: AppColors.whiteColor,
        unselectedLabelColor: AppColors.greyColor,
        tabs: tabs);
  }
}

import 'package:flutter/material.dart';

class AppColors {

  static var blackColor = const Color(0xff000000);
  static var yellowColor = const Color(0xffFFC268);
  static var greyColor = const Color(0xff999999);
  static var whiteColor = const Color(0xffFFFFFF);
  static var dividerColor = const Color(0xff262626);
  static var orangeColor = const Color(0xffC25F30);


}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_task_nada_mohsen_salah/core/Style/AppColors.dart';

class AppStyle {
  static get lightTheme => ThemeData(
      iconTheme:const IconThemeData(color: Colors.black),
      unselectedWidgetColor: Colors.grey,
      pageTransitionsTheme:const PageTransitionsTheme(builders: {
        TargetPlatform.android: FadeUpwardsPageTransitionsBuilder(),
        TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
      }),

      visualDensity: VisualDensity.adaptivePlatformDensity,
      brightness: Brightness.light,
      appBarTheme: AppBarTheme(
          systemOverlayStyle: const SystemUiOverlayStyle(
              statusBarIconBrightness: Brightness.light,
            ),
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          iconTheme: IconThemeData(color: Colors.black, size: 20.sp)),
      scaffoldBackgroundColor: AppColors.blackColor,
      textTheme: TextTheme(
          displayLarge: TextStyle(
              fontSize: 20.sp,
              fontWeight: FontWeight.bold,
              color: AppColors.whiteColor),
          displayMedium: TextStyle(
            fontSize: 14.sp,
            fontWeight: FontWeight.w700,
            color: AppColors.greyColor,
          ),
        displaySmall: TextStyle(
            fontSize: 14.sp,
            fontWeight: FontWeight.w400,
            color: AppColors.greyColor,
          ),

      ));
}

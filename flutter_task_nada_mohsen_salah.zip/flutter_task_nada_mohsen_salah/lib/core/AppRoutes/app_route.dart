import 'package:flutter/material.dart';
import 'package:flutter_task_nada_mohsen_salah/module/Home/AppLayout.dart';
import 'package:flutter_task_nada_mohsen_salah/module/Home/home_screen.dart';
import 'package:flutter_task_nada_mohsen_salah/module/Home/mobile_screen.dart';

class Routes{
  static const String home = '/home_screen';
  static const String mobile = '/MobileScreen';
  static const String appLayout = '/appLayout';

}
class AppRoute{
  static Route? onGenerateRoute(RouteSettings routeSettings) {
    final arguments = routeSettings.arguments;
    switch(routeSettings.name){
      case Routes.appLayout:
        return MaterialPageRoute(builder: (context) {
          return AppLayout();
        });
        case Routes.home:
        return MaterialPageRoute(builder: (context) {
          return HomeScreen();
        });
        case Routes.mobile:
        return MaterialPageRoute(builder: (context) {
          return MobileScreen();
        });
    }
    }
}
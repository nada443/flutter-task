import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_task_nada_mohsen_salah/core/AppRoutes/app_route.dart';

import 'core/Style/AppStyle.dart';

Future<void> main() async {
  await ScreenUtil.ensureScreenSize();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key,});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {


  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder:(BuildContext context, BoxConstraints constraints)=> ScreenUtilInit(
        designSize: constraints.maxWidth<800 ? const Size(375, 812):  const Size(1440, 900),
        minTextAdapt: true,
        splitScreenMode: true,
        builder: (context, child) {
          return SafeArea(
            top: false,
            left: false,
            right: false,
            bottom: false,
            child: MaterialApp(
              debugShowCheckedModeBanner: false,
              scrollBehavior: CustomScrollBehavior(),
              title: "Flutter Task",
              initialRoute: Routes.appLayout,
              onGenerateRoute: AppRoute.onGenerateRoute,
              theme: AppStyle.lightTheme,
            ),
          );
        } ,
      ),
    );
  }
}
class CustomScrollBehavior extends ScrollBehavior {
  @override
  ScrollPhysics getScrollPhysics(BuildContext context) {
    return const ClampingScrollPhysics(); // Or ClampingScrollPhysics()
  }
}